
package services;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static org.hamcrest.Matchers.containsString;

import java.io.File;

public class CreateNewJiraIssue extends BaseRequest {
	
	@DataProvider(name = "fetchData")
	public String[] sendFile() {
		String[] data = new String[2];
		data[0] = "./data/create.json";
		data[1] = "./data/create1.json";
		return data;
	}
	
	@Test(dataProvider = "fetchData")
	public void createNewIssue(String fileName) {
		File data = new File(fileName);
		
		Response response = request.body(data).when().post("issue").then().assertThat().statusCode(201).extract().response();

		response.prettyPrint();
		JsonPath jsonPath = response.jsonPath();
		issue_id = jsonPath.get("id");
	}

	@Test
	public void updateIssue() {
		File data = new File("./data/update.json");
		Response response = request.body(data).when().put("issue/"+issue_id).then().assertThat().statusCode(204).extract().response();
		response.prettyPrint();
	}
	
	/*
	 * @Test public void deleteIssue() {
	 * request.when().delete("issue/"+issue_id).then().assertThat().statusCode(204);
	 * 
	 * }
	 */
	
	

}
