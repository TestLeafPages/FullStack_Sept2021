package steps;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {
	public static RequestSpecification request;
	public static Response response;
	public static String issue_id;
}
