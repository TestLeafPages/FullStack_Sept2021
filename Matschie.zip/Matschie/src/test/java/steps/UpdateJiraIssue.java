package steps;

import io.cucumber.java.en.When;

public class UpdateJiraIssue extends BaseClass{

	@When("place the put request to update the new issue")
	public void placePutRequest() {
		response = request.put("issue/"+issue_id);
		response.prettyPrint();

	}
}
