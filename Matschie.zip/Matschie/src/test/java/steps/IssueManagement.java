package steps;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IssueManagement extends BaseClass {
	
	/*
	 * private RequestSpecification request; private Response response; private
	 * static String issue_id;
	 */
	
	@Given("set up the log")
	public void setUpLog() {
		request = RestAssured.given().log().all();

	}
	
	@Given("set up the content type")
	public void setUpContentType() {
		request = request.contentType(ContentType.JSON).accept(ContentType.JSON);

	}
	
	@When("set up body with {string} file")
	public void setUpBodyWithFile(String fileName) {
		File data = new File("./data/"+fileName);
		request = request.when().body(data);

	}
	
	@When("post the request to create jira issue")
	public void placePostRequest() {
		response = request.post("issue");
		response.prettyPrint();
		JsonPath jsonPath = response.jsonPath();
		issue_id = jsonPath.get("id");

	}
	
	
	
	@When("place the delete request for new issue")
	public void placeDeleteRequest() {
		response = request.delete("issue/"+issue_id);
		response.prettyPrint();

	}
	
	@Then("the status code should be {int}")
	public void verifyStatusCode(int statusCode) {
		response.then().assertThat().statusCode(statusCode);

	}
	
	@When("place the get request to retrieve all the issues$")
	public void placeGetRequest() {
		response = request.get("search");
		//response.prettyPrint();

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
